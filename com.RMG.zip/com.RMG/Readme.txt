driver download location=https://googlechromelabs.github.io/chrome-for-testing/
artifact download location=
practiceurl=https://demo.guru99.com/test/newtours/register.php