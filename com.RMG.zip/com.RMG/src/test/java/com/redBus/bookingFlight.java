package com.redBus;

import java.io.IOException;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import driver.LaunchDriver;
import driver.reusableData;
import seleniumAction.seleniumUiAction;

public class bookingFlight extends LaunchDriver {
	
	@BeforeMethod
	
	public static void launcher() {
		bookingFlight.readDriver(reusableData.driverPath, reusableData.guru99url);
		bookingFlight.maximizeBrowser();


	}
	
	
	
	@Test
	
	public static void SearchFlight() throws IOException {
		
		seleniumUiAction.entername();
		seleniumUiAction.enterPassword();
		seleniumUiAction.clickSignin();
	}
	
	@Test
public static void bookFlight() throws IOException {
		bookingFlight.scrollToBottom(driver);
		seleniumUiAction.entername();
		seleniumUiAction.enterPassword();
		seleniumUiAction.clickSignin();
	}

	
	
}
