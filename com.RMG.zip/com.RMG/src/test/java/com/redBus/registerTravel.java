package com.redBus;

import java.io.IOException;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import driver.reusableData;
import seleniumAction.seleniumUiAction;

public class registerTravel {

@BeforeMethod
	
	public static void launcher() {
		bookingFlight.readDriver(reusableData.driverPath, reusableData.newToururl);

	}
	@Test(priority =1)
	public static void contactInformation() throws IOException, InterruptedException {
		
		bookingFlight.maximizeBrowser();
		Thread.sleep(2000);
		seleniumUiAction.enterFirstname();
		Thread.sleep(2000);

		seleniumUiAction.enterLastname();
		seleniumUiAction.enterPhoneNumber();
		seleniumUiAction.enterEmail();
	}
	
	@Test(priority =2)

public static void mailingInformation() throws IOException, InterruptedException {
		
		bookingFlight.maximizeBrowser();
		Thread.sleep(3000);

		seleniumUiAction.enterAddres();
		seleniumUiAction.enterCity();
		seleniumUiAction.enterCode();
		
	}

	
}
