package seleniumAction;

import java.io.IOException;

import org.openqa.selenium.By;

import driver.LaunchDriver;
import readInputTestData.readerFile;

public class seleniumUiAction {
	public static void entername() throws IOException {
		LaunchDriver.driver.findElement(By.xpath(readerFile.readORProperties("Gurru.Demosite.Emailaddress.input"))).sendKeys("neelam.@gmail.com");	

}
	
	public static void enterPassword() throws IOException {
		LaunchDriver.driver.findElement(By.xpath(readerFile.readORProperties("Gurru.Demosite.EmailPassword.input"))).sendKeys("1234");	

}
	
	public static void clickSignin() throws IOException {
		LaunchDriver.driver.findElement(By.xpath(readerFile.readORProperties("Gurru.Demosite.SubmitLogin.button"))).click();	

}
	

	public static void enterFirstname() throws IOException {
		LaunchDriver.driver.findElement(By.xpath(readerFile.readORProperties("contact.Information.Firstname.input"))).sendKeys("shilpa");	

}
	public static void enterLastname() throws IOException {
		LaunchDriver.driver.findElement(By.xpath(readerFile.readORProperties("contact.Information.lastname.input"))).sendKeys("Biradar");	

}
	public static void enterPhoneNumber() throws IOException {
		LaunchDriver.driver.findElement(By.xpath(readerFile.readORProperties("contact.Information.phone.input"))).sendKeys("9081238766");	

}
	public static void enterEmail() throws IOException {
		LaunchDriver.driver.findElement(By.xpath(readerFile.readORProperties("contact.Information.email.input"))).sendKeys("shilpa97@gmai.com");	

}
	public static void enterAddres() throws IOException {
		LaunchDriver.driver.findElement(By.xpath(readerFile.readORProperties("Mailing.Information.address.input"))).sendKeys("kalikanagar");	

}	
	public static void enterCity() throws IOException {
		LaunchDriver.driver.findElement(By.xpath(readerFile.readORProperties("Mailing.Information.city.input"))).sendKeys("Bangalore");	

}	
	public static void enterState() throws IOException {
		LaunchDriver.driver.findElement(By.xpath(readerFile.readORProperties("Mailing.Information.state.input"))).sendKeys("Karnatak");	
}
	
	public static void enterCode() throws IOException {
		LaunchDriver.driver.findElement(By.xpath(readerFile.readORProperties("Mailing.Information.postalCode.input"))).sendKeys("586103");	
}
	
}