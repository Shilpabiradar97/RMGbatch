package driver;

public interface reusableData {
	public static String guru99url= "https://demo.guru99.com/test/login.html";
	public static String  newToururl="https://demo.guru99.com/test/newtours/register.php";
	public static String driverPath="C:\\Users\\admin\\Desktop\\com.RMG\\selenium_Driver\\chromedriver.exe";

}
